//! This module implements two-dimensional vectors, of various types.

const gba = @import("gba.zig");

/// Returns either a `Vec2I`, `Vec2U`, or `Vec2FixedI` type depending
/// on the given vector component type.
pub fn Vec2(comptime T: type) type {
    if(comptime(T == bool)) {
        return Vec2B(T);
    }
    else if(comptime(gba.math.isSignedFixedPointType(T))) {
        return Vec2I(T);
    }
    else if(comptime(gba.math.isSignedIntPrimitiveType(T))) {
        return Vec2I(T);
    }
    else if(comptime(gba.math.isUnsignedIntPrimitiveType(T))) {
        return Vec2U(T);
    }
    else {
        @compileError("No Vec2 implementation is available for this type.");
    }
}

/// Represents a vector with two boolean components.
pub const Vec2B = packed struct(u2) {
    const Self = @This();
    const T = bool;
    
    pub const one: Vec2B = .init(true, true);
    pub const zero: Vec2B = .init(false, false);
    pub const x_1: Vec2B = .init(true, false);
    pub const y_1: Vec2B = .init(false, true);
    
    pub const both = one;
    pub const neither = zero;
    pub const only_x = x_1;
    pub const only_y = y_1;
    
    x: T = false,
    y: T = false,
    
    pub fn init(x: T, y: T) Self {
        return .{ .x = x, .y = y };
    }
    
    /// Invert each component, i.e. `!self`.
    pub fn invert(self: Self) Self {
        return .{ .x = !self.x, .y = !self.y };
    }
    
    /// Returns true when both components of the vector are false.
    pub fn isNeither(self: Self) bool {
        return !self.x and !self.y;
    }
    
    /// Returns true when both components of the vector are true.
    pub fn isBoth(self: Self) bool {
        return self.x and self.y;
    }
    
    /// Logical conjunction of two vectors, i.e. `a and b`.
    pub fn conj(a: Self, b: Self) Self {
        return .init(a.x and b.x, a.y and b.y);
    }
    
    /// Logical disjunction of two vectors, i.e. `a or b`.
    pub fn disj(a: Self, b: Self) Self {
        return .init(a.x or b.x, a.y or b.y);
    }
    
    /// Check if two vectors are equal.
    pub fn eql(a: Self, b: Self) Self {
        return a.x == b.x and a.y == b.y;
    }
    
    /// Get the dot product of two vectors.
    pub fn dot(a: Self, b: Self) u2 {
        const x: u2 = @intFromBool(a.x and b.x);
        const y: u2 = @intFromBool(a.x and b.x);
        return x + y;
    }
};

/// Represents a vector with two signed components.
pub fn Vec2I(comptime T: type) type {
    const T_zero = gba.math.zero(T);
    const T_one = gba.math.one(T);
    const T_negative_one = gba.math.negativeOne(T);
    return extern struct {
        const Self = @This();
        
        pub const ComponentT: type = T;
        
        pub const zero: Self = .init(T_zero, T_zero);
        pub const one: Self = .init(T_one, T_one);
        pub const left: Self = .init(T_negative_one, T_zero);
        pub const right: Self = .init(T_one, T_zero);
        pub const up: Self = .init(T_zero, T_negative_one);
        pub const down: Self = .init(T_zero, T_one);
        pub const x_1: Self = .init(T_one, T_zero);
        pub const y_1: Self = .init(T_zero, T_one);
        
        x: T = T_zero,
        y: T = T_zero,
        
        pub fn init(x: T, y: T) Self {
            return .{ .x = x, .y = y };
        }
        
        /// Convert the vector to a different type.
        pub fn toVec2(self: Self, comptime ToComponentT: type) Vec2(ToComponentT) {
            if(comptime(ToComponentT == T)) {
                return self;
            }
            else if(comptime(gba.math.isFixedPointType(T))) {
                return .init(
                    self.x.to(ToComponentT),
                    self.y.to(ToComponentT),
                );
            }
            else if(comptime(gba.math.isFixedPointType(ToComponentT))) {
                return .init(
                    .fromInt(@intCast(self.x)),
                    .fromInt(@intCast(self.y)),
                );
            }
            else {
                return .init(
                    @intCast(self.x),
                    @intCast(self.y),
                );
            }
        }
        
        /// Convert to a three-dimensional vector type.
        pub fn toVec3(
            self: Self,
            /// The component type for the new `Vec3`.
            comptime ToComponentT: type,
            /// The Z component of the new `Vec3`.
            z: ToComponentT,
        ) gba.math.Vec3(ToComponentT) {
            const v = self.toVec2(ToComponentT);
            return .init(v.x, v.y, z);
        }
        
        /// Subtract this vector from the zero vector.
        pub fn negate(self: Self) Self {
            return .{
                .x = gba.math.negate(T, self.x),
                .y = gba.math.negate(T, self.y),
            };
        }
        
        /// Logical bit shift left on both components,
        /// with the number of bits known at comptime.
        pub fn lsl(self: Self, comptime bits: comptime_int) Self {
            return .{
                .x = gba.math.lsl(T, self.x, bits),
                .y = gba.math.lsl(T, self.y, bits),
            };
        }
        
        /// Logical bit shift right on both components,
        /// with the number of bits known at comptime.
        pub fn lsr(self: Self, comptime bits: comptime_int) Self {
            return .{
                .x = gba.math.lsr(T, self.x, bits),
                .y = gba.math.lsr(T, self.y, bits),
            };
        }
        
        /// Arithmetic bit shift right on both components,
        /// with the number of bits known at comptime.
        pub fn asr(self: Self, comptime bits: comptime_int) Self {
            return .{
                .x = gba.math.asr(T, self.x, bits),
                .y = gba.math.asr(T, self.y, bits),
            };
        }
        
        /// Logical bit shift left on both components,
        /// accepting a variable number of bits.
        pub fn lslVar(self: Self, bits: anytype) Self {
            return .{
                .x = gba.math.lslVar(T, self.x, bits),
                .y = gba.math.lslVar(T, self.y, bits),
            };
        }
        
        /// Logical bit shift right on both components,
        /// accepting a variable number of bits.
        pub fn lsrVar(self: Self, bits: anytype) Self {
            return .{
                .x = gba.math.lsrVar(T, self.x, bits),
                .y = gba.math.lsrVar(T, self.y, bits),
            };
        }
        
        /// Arithmetic bit shift right on both components,
        /// accepting a variable number of bits.
        pub fn asrVar(self: Self, bits: anytype) Self {
            return .{
                .x = gba.math.asrVar(T, self.x, bits),
                .y = gba.math.asrVar(T, self.y, bits),
            };
        }
        
        /// Returns true when both components of the vector are zero.
        pub fn isZero(self: Self) bool {
            return (
                gba.math.eql(T, self.x, T_zero) and
                gba.math.eql(T, self.y, T_zero)
            );
        }
        
        /// Get the squared magnitude of the vector.
        pub fn hypotSq(self: Self) T {
            return gba.math.add(
                T,
                gba.math.mul(T, self.x, self.x),
                gba.math.mul(T, self.y, self.y)
            );
        }
        
        /// Get the magnitude of the vector, i.e. the length of
        /// the hypotenuse of the triangle formed by this vector.
        pub fn hypot(self: Self) T {
            const sq = self.hypotSq();
            if(comptime(gba.math.isFixedPointType(T))) {
                return .initRaw(gba.bios.sqrt(sq.value));
            }
            else {
                return gba.bios.sqrt(sq);
            }
        }
        
        /// Computes the arctangent of `y / x`.
        /// Calls `gba.bios.arctan2`.
        pub fn atan2(self: Self) gba.math.FixedU16R16 {
            if(comptime(gba.math.isFixedPointType(T))) {
                return gba.bios.arctan2(
                    @intCast(self.x.value),
                    @intCast(self.y.value),
                );
            }
            else {
                return gba.bios.arctan2(
                    @intCast(self.x),
                    @intCast(self.y),
                );
            }
        }
        
        /// Add two vectors.
        pub fn add(a: Self, b: Self) Self {
            return .{
                .x = gba.math.add(T, a.x, b.x),
                .y = gba.math.add(T, a.y, b.y),
            };
        }
        
        /// Subtract vector `b` from vector `a`.
        pub fn sub(a: Self, b: Self) Self {
            return .{
                .x = gba.math.sub(T, a.x, b.x),
                .y = gba.math.sub(T, a.y, b.y),
            };
        }
        
        /// Multiply both components of a vector by a scalar value.
        pub fn scale(self: Self, scalar: T) Self {
            return .{
                .x = gba.math.mul(T, self.x, scalar),
                .y = gba.math.mul(T, self.y, scalar),
            };
        }
        
        /// Check if two vectors are equal.
        pub fn eql(a: Self, b: Self) Self {
            return (
                gba.math.eql(T, a.x, b.x) and
                gba.math.eql(T, a.y, b.y)
            );
        }
        
        /// Get the dot product of two vectors.
        pub fn dot(a: Self, b: Self) T {
            return gba.math.add(
                T,
                gba.math.mul(T, a.x, b.x),
                gba.math.mul(T, a.y, b.y),
            );
        }
    };
}

/// Represents a vector with two unsigned integer primitive components.
pub fn Vec2U(comptime T: type) type {
    return extern struct {
        const Self = @This();
        
        pub const ComponentT: type = T;
        
        pub const zero: Self = .init(0, 0);
        pub const one: Self = .init(1, 1);
        pub const x_1: Self = .init(1, 0);
        pub const y_1: Self = .init(0, 1);
        
        x: T,
        y: T,
        
        pub fn init(x: T, y: T) Self {
            return .{ .x = x, .y = y };
        }
        
        /// Convert the vector to a different type.
        pub fn toVec2(self: Self, comptime ToComponentT: type) Vec2(ToComponentT) {
            if(comptime(ToComponentT == T)) {
                return self;
            }
            else if(comptime(gba.math.isFixedPointType(ToComponentT))) {
                return .init(
                    .fromInt(@intCast(self.x)),
                    .fromInt(@intCast(self.y)),
                );
            }
            else {
                return .init(
                    @intCast(self.x),
                    @intCast(self.y),
                );
            }
        }
        
        /// Logical bit shift left on both components,
        /// with the number of bits known at comptime.
        pub fn lsl(self: Self, comptime bits: comptime_int) Self {
            return .{
                .x = gba.math.lsl(T, self.x, bits),
                .y = gba.math.lsl(T, self.y, bits),
            };
        }
        
        /// Logical bit shift right on both components,
        /// with the number of bits known at comptime.
        pub fn lsr(self: Self, comptime bits: comptime_int) Self {
            return .{
                .x = gba.math.lsr(T, self.x, bits),
                .y = gba.math.lsr(T, self.y, bits),
            };
        }
        
        /// Arithmetic bit shift right on both components,
        /// with the number of bits known at comptime.
        pub fn asr(self: Self, comptime bits: comptime_int) Self {
            return .{
                .x = gba.math.asr(T, self.x, bits),
                .y = gba.math.asr(T, self.y, bits),
            };
        }
        
        /// Logical bit shift left on both components,
        /// accepting a variable number of bits.
        pub fn lslVar(self: Self, bits: anytype) Self {
            return .{
                .x = gba.math.lslVar(T, self.x, bits),
                .y = gba.math.lslVar(T, self.y, bits),
            };
        }
        
        /// Logical bit shift right on both components,
        /// accepting a variable number of bits.
        pub fn lsrVar(self: Self, bits: anytype) Self {
            return .{
                .x = gba.math.lsrVar(T, self.x, bits),
                .y = gba.math.lsrVar(T, self.y, bits),
            };
        }
        
        /// Arithmetic bit shift right on both components,
        /// accepting a variable number of bits.
        pub fn asrVar(self: Self, bits: anytype) Self {
            return .{
                .x = gba.math.asrVar(T, self.x, bits),
                .y = gba.math.asrVar(T, self.y, bits),
            };
        }
        
        /// Returns true when both components of the vector are zero.
        pub fn isZero(self: Self) bool {
            return self.x == 0 and self.y == 0;
        }
        
        /// Get the squared magnitude of the vector, i.e. the length of
        /// the hypotenuse of the triangle formed by this vector.
        pub fn hypotSq(self: Self) T {
            return self.x * self.x + self.y * self.y;
        }
        
        /// Computes the arctangent of `y / x`.
        /// Calls `gba.bios.arctan2`.
        pub fn atan2(self: Self) gba.math.FixedU16R16 {
            return gba.bios.arctan2(@intCast(self.x), @intCast(self.y));
        }
        
        /// Add two vectors.
        pub fn add(a: Self, b: Self) Self {
            return .{
                .x = gba.math.add(T, a.x, b.x),
                .y = gba.math.add(T, a.y, b.y),
            };
        }
        
        /// Subtract vector `b` from vector `a`.
        pub fn sub(a: Self, b: Self) Self {
            return .{
                .x = gba.math.sub(T, a.x, b.x),
                .y = gba.math.sub(T, a.y, b.y),
            };
        }
        
        /// Multiply both components of a vector by a scalar value.
        pub fn scale(self: Self, scalar: T) Self {
            return .{
                .x = gba.math.mul(T, self.x, scalar),
                .y = gba.math.mul(T, self.y, scalar),
            };
        }
        
        /// Check if two vectors are equal.
        pub fn eql(a: Self, b: Self) Self {
            return (
                gba.math.eql(T, a.x, b.x) and
                gba.math.eql(T, a.y, b.y)
            );
        }
        
        /// Get the dot product of two vectors.
        pub fn dot(a: Self, b: Self) T {
            return gba.math.add(
                T,
                gba.math.mul(T, a.x, b.x),
                gba.math.mul(T, a.y, b.y),
            );
        }
    };
}

/// Two-dimensional vector with signed 8-bit integer components.
pub const Vec2I8 = Vec2I(i8);

/// Two-dimensional vector with signed 16-bit integer components.
pub const Vec2I16 = Vec2I(i16);

/// Two-dimensional vector with signed 32-bit integer components.
pub const Vec2I32 = Vec2I(i32);

/// Two-dimensional vector with unsigned 8-bit integer components.
pub const Vec2U8 = Vec2U(u8);

/// Two-dimensional vector with unsigned 16-bit integer components.
pub const Vec2U16 = Vec2U(u16);

/// Two-dimensional vector with unsigned 32-bit integer components.
pub const Vec2U32 = Vec2U(u32);

/// Two-dimensional vector with fixed point components.
pub const Vec2FixedI16R8 = Vec2I(gba.math.FixedI16R8);

/// Two-dimensional vector with fixed point components.
pub const Vec2FixedI32R8 = Vec2I(gba.math.FixedI32R8);

/// Two-dimensional vector with fixed point components.
pub const Vec2FixedI32R16 = Vec2I(gba.math.FixedI32R16);
